import tensorflow as tf

sess = tf.Session(config=tf.ConfigProto(log_device_placement=True))